//
//  ViewController.swift
//  fireBaseChat
//
//  Created by Lambda_School_Loaner_268 on 4/21/20.
//  Copyright © 2020 Lambda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

